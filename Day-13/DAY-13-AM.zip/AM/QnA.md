## Q1. Difference between `.loc[]` and `.iloc[]`

### Basic difference

- `.loc[]` is **label-based** indexing, which means it selects rows and columns by their index labels and column names.[web:322][web:324]
- `.iloc[]` is **integer position-based** indexing, which means it selects rows and columns by numeric position, starting from 0.[web:323][web:324]

### Simple example

```python
import pandas as pd

df = pd.DataFrame(
    {
        "name": ["A", "B", "C", "D", "E"],
        "marks": [docs.python](https://docs.python.org/3/library/timeit.html)
    },
    index=
)
```

#### Using `.loc[]`

```python
df.loc[1:3]
```

This returns rows with labels `1`, `2`, and `3` because `.loc[]` slicing is **inclusive** of the end label.[web:338][web:340]

#### Using `.iloc[]`

```python
df.iloc[1:3]
```

This returns rows at positions `1` and `2`, but not `3`, because `.iloc[]` follows normal Python slicing and the end index is **exclusive**.[web:323][web:324][web:336]

---

### What happens with `df.loc[0:3]` vs `df.iloc[0:3]` when index is `0,1,2,3,4`?

If the DataFrame index is numeric labels `0,1,2,3,4`:

```python
df.loc[0:3]
```

returns rows with labels `0,1,2,3`, so **4 rows** total, because `.loc[]` includes the stop label.[web:338][web:340]

```python
df.iloc[0:3]
```

returns rows at positions `0,1,2`, so **3 rows** total, because `.iloc[]` excludes the stop position.[web:323][web:324]

---

### What if the index is `'a','b','c','d','e'`?

Example:

```python
df = pd.DataFrame(
    {
        "name": ["A", "B", "C", "D", "E"],
        "marks": [docs.vultr](https://docs.vultr.com/python/standard-library/set/symmetric_difference)
    },
    index=["a", "b", "c", "d", "e"]
)
```

Now:

```python
df.loc["a":"d"]
```

returns rows with labels `"a", "b", "c", "d"` because `.loc[]` still uses labels and still includes the end label.[web:322][web:338]

But:

```python
df.iloc[0:3]
```

still returns rows at positions `0,1,2`, regardless of label names, because `.iloc[]` only cares about integer position.[web:323][web:324]

Also, this would be invalid:

```python
df.loc[0:3]
```

because labels `0` and `3` do not exist when the index is `"a","b","c","d","e"`.[web:322][web:334]

---

### Rule of thumb

- Use `.loc[]` when you want to select by **labels** or column names.[web:322][web:324]
- Use `.iloc[]` when you want to select by **row/column position**.[web:323][web:324]

---

## Q2. Coding — `analyze_csv(filepath)`

```python
import pandas as pd


def analyze_csv(filepath):
    """
    Load a CSV, print the First 5 Minutes checklist,
    and return summary information as a dictionary.
    """
    df = pd.read_csv(filepath)

    print("=== FIRST 5 MINUTES CHECKLIST ===")
    print("\n1. Shape")
    print(df.shape)

    print("\n2. Columns")
    print(df.columns.tolist())

    print("\n3. Dtypes")
    print(df.dtypes)

    print("\n4. Head")
    print(df.head())

    print("\n5. Tail")
    print(df.tail())

    print("\n6. Null counts")
    print(df.isnull().sum())

    print("\n7. Duplicate rows")
    print(df.duplicated().sum())

    print("\n8. Numeric summary")
    print(df.describe())

    memory_mb = df.memory_usage(deep=True).sum() / (1024 * 1024)

    result = {
        "num_rows": df.shape,
        "num_cols": df.shape,
        "numeric_cols": df.select_dtypes(include="number").columns.tolist(),
        "categorical_cols": df.select_dtypes(exclude="number").columns.tolist(),
        "null_counts": df.isnull().sum().to_dict(),
        "memory_mb": round(memory_mb, 4),
    }

    return result
```

### Why this is correct

- `pd.read_csv()` is the standard Pandas function for loading CSV files into a DataFrame.[web:261]
- `df.memory_usage(deep=True)` reports memory usage and `deep=True` includes more accurate memory for object columns.[web:339][web:345]
- `select_dtypes()` is a clean way to separate numeric and categorical columns in a DataFrame.[web:322]

---

## Q3. Debug — 3 bugs fixed

### Original buggy code

```python
import pandas as pd

df = pd.DataFrame({
    "name": ["Alice", "Bob", "Charlie"],
    "age":, [reddit](https://www.reddit.com/r/learnpython/comments/1e5eqv5/can_anyone_quickly_explain_the_basics_of_list/)
    "salary": 
})

# Bug 1: Wrong operator for compound condition
high_earners = df[df["age"] > 25 and df["salary"] > 55000]

# Bug 2: Chained indexing for assignment
df["age"] = 26

# Bug 3: iloc with inclusive end expectation
first_two = df.iloc[0:2]  # Expecting 3 rows (0,1,2)
print(f"Got {len(first_two)} rows, expected 3")
```

---

### Bug 1 — Wrong operator in compound condition

This line is wrong:

```python
df[df["age"] > 25 and df["salary"] > 55000]
```

In Pandas, you must use `&` for element-wise boolean comparisons, not Python’s `and`, and each condition should be wrapped in parentheses.[web:322][web:324]

### Fix

```python
high_earners = df[(df["age"] > 25) & (df["salary"] > 55000)]
```

---

### Bug 2 — Chained indexing for assignment

This line is risky:

```python
df["age"] = 26
```

This is chained indexing and can lead to ambiguous behavior or warnings. The proper way is to use `.loc[]` for assignment.[web:322]

### Fix

```python
df.loc[0, "age"] = 26
```

---

### Bug 3 — Wrong expectation with `.iloc[]`

This line:

```python
first_two = df.iloc[0:2]
```

returns rows at positions `0` and `1`, not `0,1,2`, because `.iloc[]` uses end-exclusive slicing just like normal Python slicing.[web:323][web:324][web:336]

### Fix

If you want rows `0,1,2`, use:

```python
first_three = df.iloc[0:3]
print(f"Got {len(first_three)} rows, expected 3")
```

---

## Corrected version

```python
import pandas as pd

df = pd.DataFrame({
    "name": ["Alice", "Bob", "Charlie"],
    "age":, [realpython](https://realpython.com/python-namedtuple/)
    "salary": 
})

# Fix 1: Use & with parentheses
high_earners = df[(df["age"] > 25) & (df["salary"] > 55000)]

# Fix 2: Use .loc for assignment
df.loc[0, "age"] = 26

# Fix 3: Use 0:3 if expecting rows 0,1,2
first_three = df.iloc[0:3]

print(high_earners)
print(df)
print(f"Got {len(first_three)} rows, expected 3")
```
